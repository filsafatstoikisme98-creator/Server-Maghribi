#!/usr/bin/env node
'use strict';

// Node.js launcher for the C++ server. This runs locally on the host machine;
// a browser visiting the HTML page cannot install or launch native programs.
const { spawnSync, spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const root = __dirname;
const compiler = process.env.CXX || 'clang++';
const binary = path.join(root, 'maghribibacked');
const source = path.join(root, 'src', 'main.cpp');
const port = process.env.PORT || process.argv[2] || '8080';

if (!fs.existsSync(source)) {
  console.error('Missing src/main.cpp. Run this script from the extracted project folder.');
  process.exit(1);
}

console.log(`Building with ${compiler}...`);
const build = spawnSync(compiler, ['-std=c++17', '-O2', '-Wall', '-Wextra', source, '-o', binary], {
  cwd: root, stdio: 'inherit'
});
if (build.error || build.status !== 0) {
  console.error(`Build failed. Install clang++ or set CXX to another C++ compiler.`);
  process.exit(build.status || 1);
}

console.log(`Starting MaghribiBacked on port ${port}`);
const server = spawn(binary, [String(port)], { cwd: root, stdio: 'inherit' });
server.on('error', err => { console.error('Could not start server:', err.message); process.exit(1); });
process.on('SIGINT', () => server.kill('SIGINT'));
process.on('SIGTERM', () => server.kill('SIGTERM'));
server.on('exit', code => process.exit(code ?? 0));
