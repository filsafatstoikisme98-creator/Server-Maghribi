#!/usr/bin/env bash
set -euo pipefail

DOMAIN="${1:-maghribi.com}"
shift || true
EXTRA_DOMAINS=("$@")

if [[ $EUID -ne 0 ]]; then
  echo "Jalankan dengan sudo: sudo ./deploy/setup-ssl.sh maghribi.com [www.maghribi.com]" >&2
  exit 1
fi
if [[ ! "$DOMAIN" =~ ^[A-Za-z0-9.-]+$ ]]; then
  echo "Nama domain tidak valid." >&2; exit 1
fi
for d in "${EXTRA_DOMAINS[@]}"; do
  if [[ ! "$d" =~ ^[A-Za-z0-9.-]+$ ]]; then echo "Nama domain tambahan tidak valid: $d" >&2; exit 1; fi
done

if ! command -v apt-get >/dev/null 2>&1; then
  echo "Script ini untuk Debian/Ubuntu. Instal nginx dan certbot secara manual pada distro lain." >&2
  exit 1
fi

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y nginx certbot python3-certbot-nginx

install -d -m 755 /var/www/html
sed "s/__DOMAIN__/$DOMAIN/" "$(dirname "$0")/nginx-http.conf.template" > /etc/nginx/sites-available/maghribibacked
ln -sfn /etc/nginx/sites-available/maghribibacked /etc/nginx/sites-enabled/maghribibacked
nginx -t
systemctl enable --now nginx
systemctl reload nginx

# A publicly trusted certificate can only be issued if DNS points here and inbound
# TCP ports 80/443 are reachable. Do not fabricate or bundle private keys.
CERTBOT_ARGS=(--nginx --non-interactive --agree-tos --redirect --register-unsafely-without-email -d "$DOMAIN")
for d in "${EXTRA_DOMAINS[@]}"; do CERTBOT_ARGS+=( -d "$d" ); done
certbot "${CERTBOT_ARGS[@]}"

cat <<MSG

TLS setup requested for $DOMAIN.
Certificate status:
  sudo certbot certificates
Renewal test:
  sudo certbot renew --dry-run

Start MaghribiBacked separately on loopback port 8080:
  cd /path/to/maghribibacked && ./maghribibacked 8080
Then visit https://$DOMAIN

Ensure DNS A/AAAA records point to this server and firewall allows TCP 80/443.
MSG
