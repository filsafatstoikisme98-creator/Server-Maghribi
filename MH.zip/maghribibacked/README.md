# Maghribi.com — MaghribiBacked (Clang/Linux)

Proyek gabungan: server HTTP C++ + file manager HTML + kontrol keyboard/gamepad generik + halaman PS3 HEN dari arsip yang diberikan pengguna.

## Fitur
- Server C++17 untuk Linux, dibangun dengan `clang++`.
- UI HTML responsif dengan menu File Manager, PS3 HEN Installer, dan Controller.
- API file manager: list folder, buat file/folder, baca dan simpan file teks.
- Ruang lingkup file dibatasi ke direktori `workspace/`.
- Navigasi keyboard dan dukungan Gamepad API bila browser/platform mendukungnya.
- Halaman HEN yang disertakan dari arsip PS3HEN yang diunggah: `/hen/` dan mode otomatis `/hen/auto/`.

## Build & jalankan
Instal clang di Debian/Ubuntu:
```sh
sudo apt update
sudo apt install clang make
```
Dari folder proyek:
```sh
make
./maghribibacked 8080
```
Buka `http://127.0.0.1:8080`.

Alternatif launcher:
```sh
node launcher.js 8080
```
Launcher mengompilasi backend secara lokal; JavaScript di browser tidak dapat mengompilasi atau menjalankan server native di perangkat pengunjung.

## HTTPS / SSL untuk maghribi.com
Proyek ini menggunakan Nginx sebagai reverse proxy TLS di depan backend C++. Sertifikat publik tidak dapat disertakan di ZIP: sertifikat harus diterbitkan untuk domain yang Anda kuasai, dan private key harus tetap berada di server Anda. Setup menggunakan Let's Encrypt/Certbot.

Persyaratan:
- Domain yang Anda kendalikan, dengan DNS A/AAAA mengarah ke server ini.
- Port TCP 80 dan 443 dapat dijangkau dari internet.
- Debian/Ubuntu; jalankan setup dari server hosting, bukan dari PS3.

Build ulang backend (sekarang hanya bind ke `127.0.0.1` agar tidak terekspos langsung):
```sh
make clean && make
./maghribibacked 8080
```
Di terminal lain, konfigurasi Nginx dan minta sertifikat:
```sh
sudo ./deploy/setup-ssl.sh maghribi.com
```
Jika `www.maghribi.com` juga sudah diarahkan ke server, gunakan:
```sh
sudo ./deploy/setup-ssl.sh maghribi.com www.maghribi.com
```
Kemudian buka `https://maghribi.com`. Periksa sertifikat dengan `sudo certbot certificates` dan uji pembaruan dengan `sudo certbot renew --dry-run`. Script tidak menjamin penerbitan sukses jika domain/DNS/port belum benar. Jangan membagikan private key atau file `/etc/letsencrypt/`.

Konfigurasi contoh ada di `deploy/nginx-http.conf.template`; contoh unit service ada di `deploy/maghribibacked.service.example`.

## Domain maghribi.com
`maghribi.com` dipakai sebagai nama/branding pada UI. Proyek ini tidak membuat atau mendaftarkan domain. Agar domain publik berfungsi, Anda harus memiliki domain tersebut dan mengatur DNS serta hosting/reverse proxy/TLS pada server yang Anda kendalikan. Untuk uji lokal gunakan `127.0.0.1`.

## PS3/PS2 controller
Menu Controller menyediakan petunjuk dan input keyboard/Gamepad API generik. Dukungan aktual bergantung pada browser, firmware, adaptor, dan cara controller terhubung. PS3/PS2 tidak otomatis mendukung semua API browser; ini bukan jaminan kompatibilitas universal.

## PS3 HEN
Folder `hen/` menyertakan file installer dan JavaScript dari arsip `PS3HEN-master.zip` yang disediakan pengguna, bersama README dan lisensi upstream. Menu membuka halaman installer yang disertakan. Installer dapat mengandalkan firmware/lingkungan tertentu dan sebagian alur mungkin mengunduh aset dari host upstream. Periksa firmware yang didukung, sumber, serta petunjuk proyek upstream sebelum menggunakannya. Tidak ada proses instalasi diam-diam atau otomatis dari server MaghribiBacked.

## Batasan keamanan
- Backend hanya mengakses `workspace/`, bukan seluruh storage, flash, atau folder sistem perangkat.
- Server tidak menjalankan perintah shell yang dikirim lewat browser dan tidak menyalin dirinya ke perangkat klien.
- Versi ini prototipe: TLS ditangani oleh Nginx/Certbot pada deployment, tetapi backend tidak memiliki autentikasi dan request handling belum dirancang untuk internet publik. Jangan publikasikan file manager tanpa menambahkan autentikasi dan pembatasan akses.
- Biner Linux yang dibangun di sini bukan biner PS3. Menjalankan server langsung pada PS3 memerlukan lingkungan homebrew/toolchain yang sesuai dan pengujian terpisah.

## Lisensi dan atribusi
Kode file manager MaghribiBacked adalah contoh proyek tersendiri. Materi PS3 HEN yang dibundel berasal dari arsip yang disediakan pengguna; lisensi dan README upstream disertakan di `hen/`.

## i Theme / PS3 source tree
Folder `ps3-source/` berisi isi `i Theme.zip` yang Anda berikan (direktori `lv1/`, `lv2/`, dan `payload/`). Menu **PS3 Source** menampilkan daftar folder dan pratinjau kode secara read-only melalui endpoint `/api/source/list` dan `/api/source/read`. File sumber tidak dapat diedit melalui browser dan tidak dieksekusi oleh server.

Penting: `ps3-source/payload/Makefile` memakai toolchain khusus PS3 seperti `ppu-gcc` dan `ppu-ld`. `make` pada proyek MaghribiBacked hanya membangun server Linux, bukan payload PS3. Untuk membangun payload, periksa dokumentasi sumber dan siapkan toolchain PS3 yang kompatibel; jangan menjalankan payload pada perangkat yang tidak sesuai.
